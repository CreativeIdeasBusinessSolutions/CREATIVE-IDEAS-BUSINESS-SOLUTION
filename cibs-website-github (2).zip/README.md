# Creative Ideas Business Solutions (CIBS) website

Static website (HTML, CSS, JS). No build step needed.

## Files
- `index.html` the whole website
- `assets/` logo, video posters and the 4 videos

## Admin
Open the site, click **Admin** in the footer, and log in.
Default password: `CIBS@2026` (change it in Admin > Social and settings).
Admin changes are saved in the browser you edit from. To change what every visitor sees, edit `index.html` (or ask for an update).

## Deploy on GitHub Pages
1. Create a new repository on GitHub (for example `cibs-website`), public.
2. Upload all files from this folder (keep the `assets` folder).
3. Go to **Settings > Pages**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`, and press **Save**.
4. After about a minute the site is live at `https://YOUR-USERNAME.github.io/cibs-website/`.
